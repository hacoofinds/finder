const seed = window.HACOO_SEED;
const STORAGE_KEY='hacoo_products_v4';
const LEGACY_STORAGE_KEY='hacoo_products_v3';
const OLDER_STORAGE_KEY='hacoo_products_v2';
const CODE_KEY='hacoo_discount_code';
const DEFAULT_DISCOUNT_CODE='Linkkings14';
const CREATOR_URL='https://www.tiktok.com/@hacoo.europe?_r=1&_t=ZG-9BA9P950eAb';
function shuffleCatalog(list){const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a}
let products=shuffleCatalog(loadProducts()),activeCategory='All',activeBrand='All',toastTimer;
let aiScores=null, aiSearchRun=0, clipExtractorPromise=null, productEmbeddingCache=new Map();
try{localStorage.setItem(CODE_KEY,DEFAULT_DISCOUNT_CODE)}catch(e){}
function loadProducts(){
  try{
    const current=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
    if(Array.isArray(current)){
      const merged=mergeCatalog(current);
      persistCustomProducts(merged);
      return merged;
    }
    const legacy=JSON.parse(localStorage.getItem(LEGACY_STORAGE_KEY)||'null');
    const older=Array.isArray(legacy)?legacy:JSON.parse(localStorage.getItem(OLDER_STORAGE_KEY)||'null');
    const migrated=Array.isArray(older)?mergeCatalog(older):seed.map(p=>({...p}));
    persistCustomProducts(migrated);
    return migrated;
  }catch{return seed.map(p=>({...p}))}
}
const SEED_IDS=new Set(seed.map(p=>p.id));
function persistCustomProducts(list){
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify(list.filter(p=>!SEED_IDS.has(p.id))))}catch(e){console.warn('Could not persist custom products',e)}
}
function mergeCatalog(saved){
  const list=Array.isArray(saved)?saved.map(p=>({...p})):[];
  const byId=new Map(list.map(p=>[p.id,p]));
  const refreshedIds=new Set(['initial-1','initial-2','initial-3','initial-4','initial-5','initial-6']);
  for(const original of seed){
    const existing=byId.get(original.id);
    if(!existing){const copy={...original};list.push(copy);byId.set(copy.id,copy);continue}
    // The six replacement images and new PDF batches are authoritative catalog updates.
    if(refreshedIds.has(original.id)||/^pdf-batch-(?:2|3|4|5|6|7|8|9|10|12)-/.test(original.id)){
      Object.assign(existing,original);
      continue;
    }
    if(!existing.brand&&original.brand)existing.brand=original.brand;
    if(!existing.category&&original.category)existing.category=original.category;
    if(!existing.name&&original.name)existing.name=original.name;
    if(!existing.image&&original.image)existing.image=original.image;
    if(!existing.url&&original.url)existing.url=original.url;
  }
  return list;
}
function save(){persistCustomProducts(products)}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const categoryNames=['All','Jackets','Tops','Trousers','Shoes','Accessories'];
const categoryIcon={All:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',Jackets:'<path d="M8 4 4 7l-2 9 5 1 1-5v8h8v-8l1 5 5-1-2-9-4-3-4 2-4-2Z"/>',Tops:'<path d="m8 4-5 3-1 5 5 1 1-3v10h8V10l1 3 5-1-1-5-5-3-4 2-4-2Z"/>',Trousers:'<path d="M6 3h12l1 18-6-1-1-8-1 8-6 1L6 3Z"/>',Shoes:'<path d="M3 15c3 0 5-2 6-6l3 3 4 2 5 1v4H3v-4Z"/>',Accessories:'<path d="M3 13c1-5 4-8 9-8s8 3 9 8H3Z"/><path d="M2 14h20M8 18h8"/>'};
function icon(name){return `<svg viewBox="0 0 24 24" aria-hidden="true">${categoryIcon[name]||categoryIcon.All}</svg>`}
function renderFilters(){
  const cats=categoryNames;
  document.getElementById('categories').innerHTML=cats.map(c=>`<button class="pill ${activeCategory===c?'active':''}" data-cat="${c}" aria-pressed="${activeCategory===c}">${icon(c)}${c}<small>${c==='All'?products.length:products.filter(p=>p.category===c).length}</small></button>`).join('');
  const actualBrands=[...new Set(products.map(p=>(p.brand||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  const row=document.getElementById('brandRow');
  row.style.display=actualBrands.length?'flex':'none';
  document.getElementById('brands').innerHTML=actualBrands.length?['All',...actualBrands].map(b=>`<button class="brandpill ${activeBrand===b?'active':''}" data-brand="${esc(b)}" aria-pressed="${activeBrand===b}">${esc(b)}</button>`).join(''):'';
  document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{
    const chosen=b.dataset.cat;
    activeCategory=(chosen!=='All'&&activeCategory===chosen)?'All':chosen;
    aiScores=null;
    render();
  });
  document.querySelectorAll('[data-brand]').forEach(b=>b.onclick=()=>{
    const chosen=b.dataset.brand;
    activeBrand=(chosen!=='All'&&activeBrand===chosen)?'All':chosen;
    aiScores=null;
    render();
  });
}
function render(){renderFilters();let list=[...products];const q=document.getElementById('search').value.toLowerCase().trim();if(activeCategory!=='All')list=list.filter(p=>p.category===activeCategory);if(activeBrand!=='All')list=list.filter(p=>(p.brand||'')===activeBrand);if(q)list=list.filter(p=>[p.name,p.brand,p.category].join(' ').toLowerCase().includes(q));const sort=document.getElementById('sort').value;if(aiScores){list.sort((a,b)=>(aiScores[b.id]??-1)-(aiScores[a.id]??-1));}else if(sort==='az')list.sort((a,b)=>a.name.localeCompare(b.name));if(!aiScores&&sort==='za')list.sort((a,b)=>b.name.localeCompare(a.name));if(!aiScores&&sort==='brand')list.sort((a,b)=>(a.brand||'').localeCompare(b.brand||''));document.getElementById('count').textContent=`${list.length} ${list.length===1?'ITEM':'ITEMS'}`;document.getElementById('liveCount').textContent=`${products.length} ${products.length===1?'product':'products'} in this collection`;document.getElementById('grid').classList.toggle('ai-results',!!aiScores);document.getElementById('gridHint').textContent=aiScores?'Ranked by visual similarity':'Explore the collection';document.getElementById('grid').innerHTML=list.map(p=>`<article class="card"><div class="photo"><img src="${p.image||''}" alt="${esc(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><div class="fallback"><div><b>◇</b>${esc(p.brand||'HACOO FINDS')}</div></div><span class="badge">${esc(p.category||'Find')}</span>${aiScores&&aiScores[p.id]!=null?`<span class="matchscore">Visual match · ${aiScores[p.id].toFixed(2)}</span>`:''}</div><div class="cardbody">${p.brand?`<div class="brandline">${esc(p.brand)}</div>`:'<div class="brandline">&nbsp;</div>'}<div class="productname">${esc(p.name)}</div>${p.availabilityNote?`<div class="availability-note"><strong>Availability notice</strong>${esc(p.availabilityNote)}<a href="${CREATOR_URL}" target="_blank" rel="noopener noreferrer">Follow our TikTok creators ↗</a></div>`:''}<div class="cardactions">${p.url?`<a class="btn openbtn" href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">↗ View item</a><button class="copybtn" data-copy="${esc(p.id)}" type="button">Copy link</button>`:`<button class="btn openbtn" type="button" disabled>Link needed</button><button class="copybtn" type="button" disabled>Link unavailable</button>`}</div></div></article>`).join('');document.getElementById('empty').style.display=list.length?'none':'block';document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copyProduct(b.dataset.copy))}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3000)}
async function copyProduct(id){const p=products.find(x=>x.id===id);if(!p)return;if(!p.url){toast('This product link has not been added yet.');return}const text=p.url;try{await navigator.clipboard.writeText(text);toast('Link copied! Use code Linkkings14 for 14% off your entire order.')}catch{const ta=document.createElement('textarea');ta.value=text;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const copied=document.execCommand('copy');ta.remove();toast(copied?'Link copied! Use code Linkkings14 for 14% off your entire order.':'Could not copy the link. Please try again.')}}
const codeBack=document.getElementById('codeBack');
function closeOverlay(el){el.classList.remove('show')}
function openOverlay(el){el.classList.add('show')}
function bindClose(back,buttonIds){buttonIds.forEach(id=>document.getElementById(id).onclick=()=>closeOverlay(back));back.addEventListener('click',e=>{if(e.target===back)closeOverlay(back)})}
document.getElementById('codeBtn').onclick=()=>{document.getElementById('discountCode').value=localStorage.getItem(CODE_KEY)||DEFAULT_DISCOUNT_CODE;openOverlay(codeBack)};bindClose(codeBack,['closeCode']);
document.getElementById('saveCode').onclick=()=>{closeOverlay(codeBack);toast('Your 14% discount code is ready to use at checkout.')};document.getElementById('removeCode').onclick=async()=>{await copyCode();};
async function copyCode(){const code=localStorage.getItem(CODE_KEY)||DEFAULT_DISCOUNT_CODE;try{await navigator.clipboard.writeText(code);toast('Code Linkkings14 copied — 14% off your entire order.')}catch{const ta=document.createElement('textarea');ta.value=code;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();toast('Code Linkkings14 copied — enter it at checkout for 14% off.')}}
document.getElementById('copyDiscount').onclick=copyCode;
document.getElementById('search').addEventListener('input',render);document.getElementById('sort').addEventListener('change',render);
document.getElementById('aiBtn').onclick=()=>document.getElementById('photoUpload').click();
function setAIStatus(title,detail){document.getElementById('statusTitle').textContent=title;document.getElementById('statusDetail').textContent=detail;document.getElementById('status').classList.add('show')}
function blobFromDataURL(dataUrl){return fetch(dataUrl).then(r=>r.blob())}
async function getClipExtractor(){
  if(!clipExtractorPromise){
    clipExtractorPromise=import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1').then(async mod=>{
      mod.env.allowLocalModels=false;mod.env.allowRemoteModels=true;
      return await mod.pipeline('image-feature-extraction','Xenova/clip-vit-base-patch32');
    });
  }
  return clipExtractorPromise;
}
function normalizedVector(tensor){const a=Array.from(tensor.data);let n=Math.sqrt(a.reduce((sum,v)=>sum+v*v,0))||1;return a.map(v=>v/n)}
function cosine(a,b){let sum=0;for(let i=0;i<Math.min(a.length,b.length);i++)sum+=a[i]*b[i];return Math.max(0,Math.min(1,sum))}
async function visualSearch(file){
  const run=++aiSearchRun;aiScores=null;render();
  document.getElementById('search').value='';activeCategory='All';activeBrand='All';
  setAIStatus('Loading visual search','Preparing the image model for the first search. The model downloads once and then stays cached by your browser.');
  document.getElementById('aiBtn').classList.add('ai-working');
  try{
    const extractor=await getClipExtractor();if(run!==aiSearchRun)return;
    setAIStatus('Analyzing your photo','Comparing your image with every product image in this collection…');
    const queryTensor=await extractor(file);const queryVector=normalizedVector(queryTensor);
    const scored=[];
    for(let i=0;i<products.length;i++){
      if(run!==aiSearchRun)return;
      const product=products[i];if(!product.image)continue;
      let blob;try{blob=product.image.startsWith('data:')?await blobFromDataURL(product.image):await fetch(product.image).then(r=>{if(!r.ok)throw new Error('Image could not be loaded');return r.blob()})}catch(imageError){continue}
      let vector=productEmbeddingCache.get(product.id);
      if(!vector){const tensor=await extractor(blob);vector=normalizedVector(tensor);productEmbeddingCache.set(product.id,vector)}
      scored.push({id:product.id,score:cosine(queryVector,vector)});
      setAIStatus('Finding the closest match',`Analyzed ${i+1} of ${products.length} product images…`);
    }
    if(run!==aiSearchRun)return;
    scored.sort((a,b)=>b.score-a.score);aiScores=Object.fromEntries(scored.map(x=>[x.id,x.score]));
    const best=scored[0],bestProduct=products.find(p=>p.id===best?.id);
    if(bestProduct){setAIStatus('Best visual match',`${bestProduct.name} · Similarity score ${best.score.toFixed(2)}. Results are ranked against your current collection.`)}
    else setAIStatus('No image matches','There are no product images available to compare yet.');
    render();
  }catch(err){
    console.error('Visual search error:',err);
    if(run===aiSearchRun)setAIStatus('Visual search unavailable','The AI model could not load. Check your internet connection and open this page from a website (HTTPS), then try again.');
  }finally{if(run===aiSearchRun)document.getElementById('aiBtn').classList.remove('ai-working')}
}
document.getElementById('photoUpload').onchange=e=>{const file=e.target.files?.[0];if(file)visualSearch(file)};
document.getElementById('resetPhoto').onclick=()=>{aiSearchRun++;aiScores=null;document.getElementById('photoUpload').value='';document.getElementById('status').classList.remove('show');document.getElementById('aiBtn').classList.remove('ai-working');render()};
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeOverlay(codeBack)}});

/* Per-visitor saved products and personalization */
const HACOO_OUTFITS = window.HACOO_OUTFITS;
const CREATOR_PROFILE_URL = 'https://www.tiktok.com/@hacoo.europe?_r=1&_t=ZG-9BA9P950eAb';
const SAVED_KEY = 'hacoo_saved_products_v1';
const PROFILE_KEY = 'hacoo_personal_profile_v1';
let savedProductIds = readSaved();
let userProfile = readProfile();
let currentDetailProduct = null;
let selectedProductSize = 'M';
let activeCatalogView = 'all';
let searchSaveTimer = null;
function readSaved(){try{const a=JSON.parse(localStorage.getItem(SAVED_KEY)||'[]');return new Set(Array.isArray(a)?a:[])}catch{return new Set()}}
function persistSaved(){try{localStorage.setItem(SAVED_KEY,JSON.stringify([...savedProductIds]))}catch(e){console.warn('Could not save favourites',e)}updateSavedCount()}
function readProfile(){try{return JSON.parse(localStorage.getItem(PROFILE_KEY)||'{"brands":{},"categories":{},"terms":{},"recent":[]}')}catch{return {brands:{},categories:{},terms:{},recent:[]}}}
function persistProfile(){try{localStorage.setItem(PROFILE_KEY,JSON.stringify(userProfile))}catch(e){}}
function recordProductActivity(p,kind){if(!p)return;const amount=kind==='save'?3:kind==='copy'?2:1;if(p.brand)userProfile.brands[p.brand]=(userProfile.brands[p.brand]||0)+amount;if(p.category)userProfile.categories[p.category]=(userProfile.categories[p.category]||0)+amount;userProfile.recent=[p.id,...(userProfile.recent||[]).filter(id=>id!==p.id)].slice(0,12);persistProfile()}
function recordSearchTerm(q){q=(q||'').toLowerCase().trim();if(q.length<2)return;for(const word of q.split(/\s+/).filter(w=>w.length>2).slice(0,5))userProfile.terms[word]=(userProfile.terms[word]||0)+1;persistProfile()}
function seasonName(){const m=new Date().getMonth();if([10,11,0,1].includes(m))return 'winter';if([2,3,4].includes(m))return 'spring';if([5,6,7].includes(m))return 'summer';return 'autumn'}
function seasonCopy(){const s=seasonName();const copy={winter:['WINTER ESSENTIALS','Winter essentials.','Cold-weather essentials selected for the season.','Winter essentials','Puffers, parkas and elevated layers'],spring:['SPRING SELECTION','The spring edit.','Light layers and everyday pieces for changing days.','Spring edit','Fresh layers and everyday favourites'],summer:['SUMMER SELECTION','Summer essentials.','Easy pieces and lighter looks for warmer days.','Summer edit','Lightweight favourites for the season'],autumn:['AUTUMN SELECTION','The autumn edit.','Transitional layers and everyday essentials.','Autumn edit','Layering pieces for cooler days']};return copy[s]}
function winterScore(p){const s=seasonName();let score=0;const text=((p.name||'')+' '+(p.brand||'')+' '+(p.category||'')).toLowerCase();if(s==='winter'){if(/canada goose|moncler|parajumpers/.test(text))score+=8;if(/puffer|down|parka|winter|padded|quilted|fur-trimmed/.test(text))score+=6;if(p.category==='Jackets')score+=3;if(/hoodie|sweatshirt|knit|jacket|coat/.test(text))score+=1.5}else{if(/jacket|hoodie|sweatshirt|trousers|sneaker/.test(text))score+=1;if(p.category==='Tops'||p.category==='Shoes')score+=1.5}return score}
function personalizedScore(p){let score=winterScore(p);score+=(userProfile.brands[p.brand]||0)*1.5;score+=(userProfile.categories[p.category]||0)*.7;const recentIndex=(userProfile.recent||[]).indexOf(p.id);if(recentIndex>=0)score+=Math.max(0,4-recentIndex*.35);const text=((p.name||'')+' '+(p.brand||'')+' '+(p.category||'')).toLowerCase();for(const [term,weight] of Object.entries(userProfile.terms||{})){if(term.length>2&&text.includes(term))score+=Math.min(weight,4)*.65}return score}
function updateSavedCount(){const el=document.getElementById('savedCount');if(el)el.textContent=String(savedProductIds.size);const mobile=document.getElementById('mobileSavedCount');if(mobile)mobile.textContent=String(savedProductIds.size)}
function seasonalCandidates(){return [...products].sort((a,b)=>winterScore(b)-winterScore(a)).filter(p=>winterScore(p)>=3).slice(0,5)}
function productDescription(p){if(p.description)return p.description;let name=p.name||'This item';const brand=p.brand&&p.brand!=='Brand not confirmed'?p.brand:'';if(brand&&name.toLowerCase().startsWith(brand.toLowerCase()))name=name.slice(brand.length).replace(/^\s*[-–—:]?\s*/,'');const category=(p.category||'fashion').toLowerCase();return `${brand?brand+' ':''}${name} is part of the HACOO FINDS ${category} selection. Explore the product details, choose a size from S to L, and continue to the product listing to check the latest options and availability.`}
function productCardMarkup(p){const saved=savedProductIds.has(p.id);return `<article class="card product-card"><div class="photo" data-open-product="${esc(p.id)}"><img src="${p.image||''}" alt="${esc(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><div class="fallback"><div><b>◇</b>${esc(p.brand||'HACOO FINDS')}</div></div><span class="badge">${esc(p.category||'Find')}</span><button class="save-toggle ${saved?'saved':''}" data-save="${esc(p.id)}" type="button" aria-label="${saved?'Remove from saved':'Save product'}">${saved?'♥':'♡'}</button></div><div class="cardbody"><div class="brandline" data-open-product="${esc(p.id)}">${p.brand?esc(p.brand):'&nbsp;'}</div><div class="productname" data-open-product="${esc(p.id)}">${esc(p.name)}</div>${p.availabilityNote?`<div class="availability-note"><strong>Availability notice</strong>${esc(p.availabilityNote)}<a href="${CREATOR_PROFILE_URL}" target="_blank" rel="noopener noreferrer">Follow our TikTok creators ↗</a></div>`:''}<div class="cardactions"><button class="btn openbtn" data-detail="${esc(p.id)}" type="button">View product</button>${p.url?`<button class="copybtn" data-copy="${esc(p.id)}" type="button">Copy link</button>`:`<button class="copybtn" type="button" disabled>Link unavailable</button>`}</div></div></article>`}
function attachProductGridHandlers(container){if(!container||container.dataset.hacooHandlers==='1')return;container.dataset.hacooHandlers='1';container.addEventListener('click',e=>{const save=e.target.closest('[data-save]');if(save){e.preventDefault();e.stopPropagation();toggleSaved(save.dataset.save);return}const copy=e.target.closest('[data-copy]');if(copy){e.preventDefault();e.stopPropagation();copyProduct(copy.dataset.copy);return}const detail=e.target.closest('[data-detail], [data-open-product]');if(detail){e.preventDefault();openProductDetail(detail.dataset.detail||detail.dataset.openProduct)}})}
function renderSeasonal(){const [eyebrow,title,subtitle,heading,subheading]=seasonCopy();document.getElementById('seasonEyebrow').textContent=eyebrow;document.getElementById('seasonTitle').textContent=title;document.getElementById('seasonSubtitle').textContent=subtitle;document.getElementById('seasonalHeading').textContent=heading;document.getElementById('seasonalSubheading').textContent=subheading;const picks=seasonalCandidates();document.getElementById('seasonalBlock').style.display=picks.length?'block':'none';document.getElementById('seasonalGrid').innerHTML=picks.map(productCardMarkup).join('');attachProductGridHandlers(document.getElementById('seasonalGrid'))}
function renderOutfits(){const grid=document.getElementById('outfitGrid');grid.innerHTML=HACOO_OUTFITS.map(o=>`<article class="outfit-card" data-outfit="${o.id}" tabindex="0" role="button" aria-label="View ${esc(o.title)}"><img src="${o.image}" alt="${esc(o.title)}" loading="lazy"><div class="outfit-meta"><strong>${esc(o.title)}</strong><span>View outfit ↗</span></div></article>`).join('');grid.addEventListener('click',e=>{const card=e.target.closest('[data-outfit]');if(card)openOutfit(card.dataset.outfit)});grid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-outfit]')){e.preventDefault();openOutfit(e.target.dataset.outfit)}})}
function render(){renderFilters();const q=document.getElementById('search').value.toLowerCase().trim();let list=[...products];if(activeCategory!=='All')list=list.filter(p=>p.category===activeCategory);if(activeBrand!=='All')list=list.filter(p=>(p.brand||'')===activeBrand);if(q)list=list.filter(p=>[p.name,p.brand,p.category].join(' ').toLowerCase().includes(q));const sort=document.getElementById('sort').value;if(aiScores){list.sort((a,b)=>(aiScores[b.id]??-1)-(aiScores[a.id]??-1))}else if(sort==='az')list.sort((a,b)=>a.name.localeCompare(b.name));else if(sort==='za')list.sort((a,b)=>b.name.localeCompare(a.name));else if(sort==='brand')list.sort((a,b)=>(a.brand||'').localeCompare(b.brand||''));else {
  const hasPersonalSignals=(userProfile.recent||[]).length>0||Object.keys(userProfile.brands||{}).length>0||Object.keys(userProfile.categories||{}).length>0||Object.keys(userProfile.terms||{}).length>0;
  const isCanadaGooseJacket=p=>(String(p.brand||'').trim().toLowerCase()==='canada goose'&&String(p.category||'').toLowerCase()==='jackets');
  list.sort((a,b)=>{
    const aPinned=isCanadaGooseJacket(a),bPinned=isCanadaGooseJacket(b);
    if(aPinned!==bPinned)return bPinned?1:-1;
    // A fresh visit keeps the rest of the catalog in its already-randomized order.
    // Once the visitor has interacted, the existing personal ranking takes over.
    return hasPersonalSignals?personalizedScore(b)-personalizedScore(a):0;
  });
}document.getElementById('count').textContent=`${list.length} ${list.length===1?'ITEM':'ITEMS'}`;document.getElementById('liveCount').textContent=`${products.length} ${products.length===1?'product':'products'} in this collection`;document.getElementById('grid').classList.toggle('ai-results',!!aiScores);document.getElementById('gridHint').textContent=aiScores?'Ranked by visual similarity':(q?'Matching your search':'Recommended for you · Adapts to your activity');const grid=document.getElementById('grid');grid.innerHTML=list.map(productCardMarkup).join('');attachProductGridHandlers(grid);document.getElementById('empty').style.display=list.length?'none':'block';const savedView=activeCatalogView==='saved';document.getElementById('seasonHero').style.display=savedView?'none':'flex';document.getElementById('seasonalBlock').style.display=savedView?'none':(seasonalCandidates().length?'block':'none');document.getElementById('catalogTitle').textContent=savedView?'Saved products':'All products';grid.style.display=savedView?'none':'grid';document.getElementById('empty').style.display=savedView?'none':(list.length?'none':'block');const savedSection=document.getElementById('savedSection');savedSection.hidden=!savedView;if(savedView){const savedList=products.filter(p=>savedProductIds.has(p.id)).sort((a,b)=>personalizedScore(b)-personalizedScore(a));const sg=document.getElementById('savedGrid');sg.innerHTML=savedList.map(productCardMarkup).join('');attachProductGridHandlers(sg);document.getElementById('savedEmpty').style.display=savedList.length?'none':'block'}updateSavedCount()}
function toggleSaved(id){const p=products.find(x=>x.id===id);if(!p)return;if(savedProductIds.has(id)){savedProductIds.delete(id);toast('Removed from saved products.')}else{savedProductIds.add(id);recordProductActivity(p,'save');toast('Added to saved products.')}persistSaved();render()}
function openProductDetail(id){const p=products.find(x=>x.id===id);if(!p)return;currentDetailProduct=p;selectedProductSize='M';recordProductActivity(p,'view');document.getElementById('detailImage').src=p.image||'';document.getElementById('detailImage').alt=p.name;document.getElementById('detailBrand').textContent=p.brand||'HACOO FINDS';document.getElementById('detailName').textContent=p.name;document.getElementById('detailDescription').textContent=productDescription(p);document.getElementById('selectedSizeLabel').textContent='Selected: M';document.querySelectorAll('.size-option').forEach(b=>b.classList.toggle('active',b.dataset.size==='M'));const saved=savedProductIds.has(id);const saveBtn=document.getElementById('detailSave');saveBtn.textContent=saved?'♥ Saved':'♡ Save';saveBtn.classList.toggle('solid',saved);const availability=document.getElementById('detailAvailability');availability.hidden=!p.availabilityNote;availability.textContent=p.availabilityNote||'';document.getElementById('buyNow').disabled=!p.url;document.getElementById('buyNow').textContent=p.url?'Buy now ↗':'Link unavailable';render();document.getElementById('productDetailBack').classList.add('show')}
function closeProductDetail(){document.getElementById('productDetailBack').classList.remove('show')}
function openOutfit(id){const outfit=HACOO_OUTFITS.find(o=>o.id===id);if(!outfit)return;document.getElementById('outfitDetailImage').src=outfit.image;document.getElementById('outfitDetailTitle').textContent=outfit.title;document.getElementById('outfitDetailDescription').textContent=outfit.description;document.getElementById('outfitDetailBack').classList.add('show')}
function closeOutfit(){document.getElementById('outfitDetailBack').classList.remove('show')}
function updateProductDetailSave(){if(!currentDetailProduct)return;const b=document.getElementById('detailSave');const saved=savedProductIds.has(currentDetailProduct.id);b.textContent=saved?'♥ Saved':'♡ Save';b.classList.toggle('solid',saved)}
async function copyProduct(id){const p=products.find(x=>x.id===id);if(!p||!p.url){toast('This product link has not been added yet.');return}try{await navigator.clipboard.writeText(p.url);recordProductActivity(p,'copy');toast('Link copied! Use code Linkkings14 for 14% off your entire order.')}catch{const ta=document.createElement('textarea');ta.value=p.url;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();if(ok){recordProductActivity(p,'copy');toast('Link copied! Use code Linkkings14 for 14% off your entire order.')}else toast('Could not copy the link. Please try again.')}}
function trackSearch(){const q=document.getElementById('search').value;if(searchSaveTimer)clearTimeout(searchSaveTimer);searchSaveTimer=setTimeout(()=>recordSearchTerm(q),900)}
document.getElementById('search').addEventListener('input',trackSearch);
document.getElementById('savedNav').addEventListener('click',()=>{activeCatalogView=activeCatalogView==='saved'?'all':'saved';aiScores=null;render();document.getElementById('catalogSection').scrollIntoView({behavior:'smooth',block:'start'})});
document.getElementById('backToProducts').addEventListener('click',()=>{activeCatalogView='all';render();document.getElementById('catalogSection').scrollIntoView({behavior:'smooth',block:'start'})});
document.getElementById('outfitsNav').addEventListener('click',()=>document.getElementById('outfitsSection').scrollIntoView({behavior:'smooth',block:'start'}));
document.getElementById('mobileOutfitsNav').addEventListener('click',()=>document.getElementById('outfitsSection').scrollIntoView({behavior:'smooth',block:'start'}));
document.getElementById('mobileSavedNav').addEventListener('click',()=>{activeCatalogView='saved';aiScores=null;render();document.getElementById('catalogSection').scrollIntoView({behavior:'smooth',block:'start'})});
document.getElementById('closeProductDetail').addEventListener('click',closeProductDetail);
document.getElementById('productDetailBack').addEventListener('click',e=>{if(e.target.id==='productDetailBack')closeProductDetail()});
document.getElementById('closeOutfitDetail').addEventListener('click',closeOutfit);
document.getElementById('outfitDetailBack').addEventListener('click',e=>{if(e.target.id==='outfitDetailBack')closeOutfit()});
document.querySelectorAll('.size-option').forEach(b=>b.addEventListener('click',()=>{selectedProductSize=b.dataset.size;document.querySelectorAll('.size-option').forEach(x=>x.classList.toggle('active',x===b));document.getElementById('selectedSizeLabel').textContent='Selected: '+selectedProductSize;document.getElementById('buyNow').textContent='Buy now · '+selectedProductSize+' ↗'}));
document.getElementById('buyNow').addEventListener('click',()=>{if(!currentDetailProduct?.url)return;recordProductActivity(currentDetailProduct,'buy');window.open(currentDetailProduct.url,'_blank','noopener,noreferrer');toast('Opening the product page. Check size '+selectedProductSize+' there before checkout.')});
document.getElementById('detailSave').addEventListener('click',()=>{if(currentDetailProduct){toggleSaved(currentDetailProduct.id);updateProductDetailSave()}});
document.getElementById('detailCopy').addEventListener('click',()=>{if(currentDetailProduct)copyProduct(currentDetailProduct.id)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeProductDetail();closeOutfit()}});
// Reorder the seasonal shelf and the full catalogue using the shopper's local interaction profile.
renderOutfits();renderSeasonal();render();

