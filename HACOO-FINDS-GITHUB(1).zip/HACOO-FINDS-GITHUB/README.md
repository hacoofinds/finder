# HACOO FINDS

Eine statische, für **GitHub Pages** vorbereitete Fashion-Website im Apple-inspirierten Dark Design.

**Enthalten:** 222 Produkte und 16 Outfit-Looks.

## Projektstruktur

- `index.html` – Startseite und HTML-Grundgerüst
- `css/styles.css` – Design, responsive Layouts und Produktdetailansicht
- `js/catalog.js` – Produktkatalog und Outfit-Daten
- `js/app.js` – Suche, Kategorien, Markenfilter, Bildsuche, Produktdetails, Merkliste und persönliche Empfehlungen
- `assets/products/` – Produktbilder
- `assets/outfits/` – Bilder der Outfit-Galerie
- `assets/winter-essentials-background.jpg` – Hintergrund für Winter Essentials
- `.nojekyll` – verhindert unerwünschte Jekyll-Verarbeitung durch GitHub Pages

## Website auf GitHub veröffentlichen

1. Erstelle auf GitHub ein neues Repository, zum Beispiel `hacoo-finds`.
2. Öffne das Repository und wähle **Add file → Upload files**.
3. Öffne den heruntergeladenen Projektordner `HACOO-FINDS-GITHUB` und lade **alle Inhalte** hoch: `index.html`, `css/`, `js/`, `assets/` sowie die übrigen Dateien. Wichtig: `index.html` muss im obersten Repository-Ordner liegen.
4. Bestätige den Upload mit **Commit changes**.
5. Öffne **Settings → Pages**.
6. Wähle unter **Build and deployment** die Option **Deploy from a branch**.
7. Wähle den Branch `main` und den Ordner `/(root)`, dann **Save**.
8. Nach der Veröffentlichung zeigt GitHub Pages dort die öffentliche Website-Adresse an.

Du brauchst dafür keinen Build-Befehl, kein npm und keinen eigenen Server. Die Website ist eine statische HTML/CSS/JavaScript-Seite.

## Persönliche Daten: Merkliste und Empfehlungen

Gespeicherte Produkte und die persönlichen Empfehlungssignale werden mit `localStorage` im Browser des jeweiligen Besuchers gespeichert.

- Besucher mit eigenen Geräten oder getrennten Browser-Profilen haben getrennte Merklisten und Empfehlungssignale.
- Diese Daten werden **nicht** an GitHub oder einen gemeinsamen Server übertragen und sind für andere Besucher nicht sichtbar.
- Die Daten werden nicht automatisch zwischen Smartphone und Computer synchronisiert.
- Wenn Website-/Browserdaten gelöscht werden, kann die lokale Merkliste verloren gehen.
- Mehrere Personen, die dasselbe Gerät im selben Browser-Profil verwenden, teilen dessen lokalen Speicher. Für getrennte Listen braucht jede Person ein eigenes Browser-Profil.

Der Produktkatalog ist öffentlich und für alle Besucher gleich. Nur Merkliste und Personalisierung sind lokal und individuell.

## KI-Bildsuche

Die visuelle Produktsuche lädt beim ersten Einsatz das Bildmodell über Transformers.js von öffentlichen CDN-/Model-Servern. Dafür ist eine Internetverbindung erforderlich. Die Produktbilder und die übrigen Website-Dateien sind im Repository enthalten.

## Katalog aktualisieren

Produkte werden in `window.HACOO_SEED` in `js/catalog.js` gepflegt. Lege neue Bilder unter `assets/products/` ab und verwende im Katalog einen relativen Pfad, zum Beispiel `assets/products/example.jpg`. Outfit-Einträge stehen in `window.HACOO_OUTFITS`.

## Produktlinks und Rabattcode

Die Produktbuttons öffnen den zugehörigen externen Produktlink. Der angezeigte Rabattcode lautet `Linkkings14`. Der Code muss beim Checkout eingegeben werden; ob er angenommen wird, hängt vom externen Händler ab.
